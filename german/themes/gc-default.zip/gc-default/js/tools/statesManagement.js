$(function() {
	bindStateInputAndUpdate();
});

function bindStateInputAndUpdate()
{	
	updateState();
	updateNeedIDNumber();
	updateZipCode();
	
	$('select#guest_id_country').change(function(){
		updateState('guest');
		updateNeedIDNumber('guest');
		updateZipCode('guest');
	});
	
	$('select#new_id_country').change(function(){
		updateState('new');
		updateNeedIDNumber('new');
		updateZipCode('new');
	});
}

function updateState(suffix) {
	if(suffix === undefined) {
		updateState('guest');
		updateState('new');
		return;
	}
	
	$('select#'+suffix+'_id_state option:not(:first-child)').remove();
	var states = countries[$('select#'+suffix+'_id_country').val()];
	if(typeof(states) !== 'undefined')
	{
		$(states).each(function (key, item){
			$('select#'+suffix+'_id_state').append('<option value="'+item.id+'"'+ (idSelectedCountry == item.id ? ' selected="selected"' : '') + '>'+item.name+'</option>');
		});
		
		$('p.'+suffix+'_id_state:hidden').slideDown('slow');
	}
	else
		$('p.'+suffix+'_id_state').hide();
}

function updateNeedIDNumber(suffix) {
	if(suffix === undefined) {
		updateNeedIDNumber('guest');
		updateNeedIDNumber('new');
		return;
	}
	
	var idCountry = parseInt($('select#'+suffix+'_id_country').val());

	if ($.inArray(idCountry, countriesNeedIDNumber) >= 0)
		$('.'+suffix+'_dni:hidden').slideDown('slow');
	else
		$('.'+suffix+'_dni').hide();
}

function updateZipCode(suffix)
{
	if(suffix === undefined) {
		updateZipCode('guest');
		updateZipCode('new');
		return;
	}
	
	var idCountry = parseInt($('select#'+suffix+'_id_country').val());
	
	if (countriesNeedZipCode[idCountry] !== 0)
		$('#'+suffix+'_postcode:hidden').slideDown('slow');
	else
		$('#'+suffix+'_postcode').slideUp('fast');
}
