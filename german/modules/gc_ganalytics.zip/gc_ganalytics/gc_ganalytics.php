<?php

/**
 * 
 * GC Google Analytics
 * Module for Prestashop E-Commerce Software
 * 
 * @description PrestaShop module for google analytics
 * @author      Markus Engel <info@onlineshop-module.de>
 * @copyright   Copyright (c) 2013, Onlineshop-Module.de
 * @license     commercial, see licence.txt
 *
 */

if (!defined('_PS_VERSION_'))
	exit;

class GC_Ganalytics extends Module {
	
	function __construct() {
	 	
		$this->name          = 'gc_ganalytics';
	 	$this->tab           = 'analytics_stats';
	 	$this->version       = '2.2.1';
		$this->author        = 'Onlineshop-Module.de';
		$this->need_instance = 1;
		$this->ps_versions_compliancy = array(
			'min' => '1.5',
			'max' => '1.6'
		);
		
	 	parent::__construct();
		
		$this->displayName      = $this->l('Google Analytics');
		$this->description      = $this->l('Integrate Google Analytics script into your shop');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details ?');
		
		$this->checkDependencies();
		
	}

	function install() {
		
		$return = true;
		
		$return &= parent::install();
		
		$return &= $this->registerHook('displayHeader');
		$return &= $this->registerHook('displayOrderConfirmation');
		
		$return &= Configuration::updateValue('GC_GANALYTICS_ID', '');
		$return &= Configuration::updateValue('GC_GANALYTICS_SSSR', 50);
		
		return $return;
		
	}

	function uninstall() {
		
		$return = true;
		
		$return &= Configuration::deleteByName('GC_GANALYTICS_ID');
		$return &= Configuration::deleteByName('GC_GANALYTICS_SSSR');
		
		$return &= parent::uninstall();
		
		return $return;
		
	}

	public function getContent() {
		
		$html = '';
		
		$html .= '<img src="'.$this->_path.'logo.png'.'" alt="'.$this->displayName.'" class="float" style="margin:0 20px 20px 0;" />';
		$html .= '<h1>'.$this->displayName.' - '.$this->author.'</h1>';
		$html .= '<p>'.$this->description.'</p>';
		$html .= '<p><a class="link" href="'.$this->_path.'licence.txt" target="_blank">'.$this->l('Please consider our license disclaimer.').'</a></p>';
		
		if($postProcess = $this->postProcess() and !empty($postProcess));
			$postProcess .= '<img src="http://www.onlineshop-module.de/pml.gif?module='.$this->name.'&domain='.$this->context->shop->domain.'&version='.$this->version.'" style="display:none;" />';
		
		$html .= $postProcess;
		
		$html .= $this->displayForm();
		
		return $html;
		
	}
	
	public function postProcess() {
		
		if(Tools::isSubmit('submitGCGanalytics')) {
			
			if(!$ganalytics_id = Tools::getValue('GC_GANALYTICS_ID') or !preg_match('#UA-[0-9]{5,10}-[0-9]{1,3}#', $ganalytics_id))
				return $this->displayError($this->l('Your Google Analytics ID has a incorrect format.'));
			
			if(!$ganalytics_sssr = (int)Tools::getValue('GC_GANALYTICS_SSSR') or $ganalytics_sssr < 0 or $ganalytics_sssr > 100)
				return $this->displayError($this->l('The Side Speed Sample Rate mus be a value between 0 and 100'));
			
			Configuration::updateValue('GC_GANALYTICS_ID', $ganalytics_id);
			Configuration::updateValue('GC_GANALYTICS_SSSR', $ganalytics_sssr);
			
			return $this->displayConfirmation($this->l('Settings updated'));
			
		}
		
	}

	public function displayForm() {
		
		$html = '';
		
		if($warning = $this->checkDependencies())
			$html .= '<div class="warning">'.$warning.'</div>';
		
		$html .= '
			<form action="'.Tools::safeOutput($_SERVER['REQUEST_URI']).'" method="post">
				<fieldset>
					<legend>'.$this->l('Settings').'</legend>
					
					<label>'.$this->l('Your GA ID').'</label>
					<div class="margin-form">
						<input type="text" name="GC_GANALYTICS_ID" value="'.Tools::safeOutput(Tools::getValue('GC_GANALYTICS_ID', Configuration::get('GC_GANALYTICS_ID'))).'" />
						<p class="clear">'.$this->l('Example:').' UA-1234567-1</p>
					</div>
					
					<label>'.$this->l('Side Speed Sample Rate').'</label>
					<div class="margin-form">
						<input type="text" name="GC_GANALYTICS_SSSR" value="'.Tools::safeOutput(Tools::getValue('GC_GANALYTICS_SSSR', Configuration::get('GC_GANALYTICS_SSSR'))).'" />
						<p class="clear">'.$this->l('This setting determines how often site speed tracking beacons will be sent in percent (%)').'</p>
					</div>
					
					<label>'.$this->l('Exclude Tracking').'</label>
					<div class="margin-form">
						<p style="font-weight:bold;font-size:12px;">'.htmlentities('<a href="?exclude_analytics=1" id="ganalytics_exclude">Exclude me from Google Analytics tracking!</a>').'</p>
						<p class="clear">'.$this->l('Insert this link in your privacy policy cms page. With this users can exclude their tracking.').'</p>
					</div>
					<input type="submit" name="submitGCGanalytics" value="'.$this->l('Update ID').'" class="button" />
				</fieldset>
			</form>';

		return $html;
		
	}

	function hookDisplayHeader($params) {
		
		if(!$this->isActive())
			return;
		
		if(($exclude_analytics = Tools::getValue('exclude_analytics')) !== false and Validate::isBool($exclude_analytics)) {
			$this->context->cookie->exclude_analytics = $exclude_analytics;
		}
		
		if(isset($this->context->cookie->exclude_analytics) and $this->context->cookie->exclude_analytics)
			return '';
		
		$controller = basename(Tools::getValue('controller'));
		
		if($controller == 'order' or $controller == 'gcorder')
			$pageTrack = '/order/step'.(int)Tools::getValue('step').'.html';
		elseif($controller == 'authentication' and Tools::getValue('in_order_process') == '1')
			$pageTrack = '/order/step1_auth.html';
		else
			$pageTrack = false;
		
		$this->context->smarty->assign(array(
			'ganalytics_id'   => Configuration::get('GC_GANALYTICS_ID'),
			'ganalytics_sssr' => (int)Configuration::get('GC_GANALYTICS_SSSR'),
			'pageTrack'       => $pageTrack
		));
		
		$this->context->smarty->assign('isOrder', false);
		
		return $this->display(__FILE__, 'displayHeader.tpl');
		
	}
	
	function hookDisplayFooter($params) {
		
		return $this->hookDisplayHeader($params);
		
	}

	function hookDisplayOrderConfirmation($params) {
		
		if(!$this->isActive())
			return;
		
		if(isset($this->context->cookie->exclude_analytics) and $this->context->cookie->exclude_analytics)
			return '';

		$order = $params['objOrder'];
		
		if (Validate::isLoadedObject($order))
		{
			$deliveryAddress = new Address($order->id_address_delivery);

			$conversion_rate = 1;
			
			if ($order->id_currency != Configuration::get('PS_CURRENCY_DEFAULT'))
			{
				$currency = new Currency($order->id_currency);
				$conversion_rate = (float)$currency->conversion_rate;
			}

			// Order general information
			
			if($deliveryAddress->id_state and $state = new State($deliveryAddress->id_state) and Validate::isLoadedObject($state)) {
				$state_name = $state->name;
			}
			else {
				$state_name = '';
			}
			
			$trans = array(
				'id'       => $order->id,
				'store'    => htmlentities($this->context->shop->name),
				'total'    => Tools::ps_round((float)$order->total_paid_tax_incl / $conversion_rate, 2),
				'tax'      => Tools::ps_round(((float)$order->total_paid_tax_incl - (float)$order->total_discounts_tax_excl) / $conversion_rate),
				'shipping' => Tools::ps_round((float)$order->total_shipping / $conversion_rate, 2),
				'city'     => addslashes($deliveryAddress->city),
				'state'    => $state_name,
				'country'  => addslashes($deliveryAddress->country)
			);

			// Product information
			$products = $order->getProducts();
			$items = array();
			
			foreach ($products AS $product) {
				
				$category = Db::getInstance()->getRow('
					SELECT name FROM `'._DB_PREFIX_.'category_lang` , '._DB_PREFIX_.'product
					WHERE `id_product` = '.$product['product_id'].' AND `id_category_default` = `id_category`
					AND `id_lang` = \''.$order->id_lang.'\'
				');

				$items[] = array(
					'OrderId'  => (int)$order->id,
					'SKU'      => $product['product_id'].'_'.$product['product_attribute_id'],
					'Product'  => addslashes($product['product_name']),
					'Category' => addslashes($category['name']),
					'Price'    => Tools::ps_round((float)$product['product_price_wt'] / $conversion_rate, 2),
					'Quantity' => addslashes($product['product_quantity'])
				);
				
			}
			
			$this->context->smarty->assign('isOrder', true);

			$this->context->smarty->assign(array(
				'items'         => $items,
				'trans'         => $trans
			));
			
			return $this->display(__FILE__, 'displayOrderConfirmation.tpl');
			
		}
		
	}
	
	public function checkDependencies() {
		
		$blockcart = Module::getInstanceByName('blockcart');
		
		if($blockcart and Validate::isLoadedObject($blockcart))
			return $this->warning = $this->l('Please be carefull: Some functions of gc_ganalytics will not work with blockcart. Please install the gc_blockcart module instead.');
		
	}
	
	public function isActive() {
		
		$active = true;
		
		$active &= $this->active;
		$active &= (bool)Configuration::get('GC_GANALYTICS_ID');
		
		return $active;
		
	}
	
}
