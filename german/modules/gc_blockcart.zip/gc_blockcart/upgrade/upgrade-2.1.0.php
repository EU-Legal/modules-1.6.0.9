<?php

function upgrade_module_2_1_0($gc_blockcart) {

	$result = true;
	
	$result &= $gc_blockcart->removeOverride('CartController');
	$result &= $gc_blockcart->addOverride('CartController');
	
	return $result;
	
}