<?php

include_once(dirname(__FILE__).'/gc_blockcart.php');

$context = Context::getContext();
$gc_blockCart = new GC_BlockCart();

echo $gc_blockCart->hookDisplayAjaxCall(array('cookie' => $context->cookie, 'cart' => $context->cart));