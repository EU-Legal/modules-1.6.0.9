<?php

class CartController extends CartControllerCore
{
	public function displayAjax()
	{
		
		/*
		| GC Cart 1.5.6.0 | 20131024
		| GC Blockcart laden
		*/
		
		if ($this->errors)
			die(Tools::jsonEncode(array('hasError' => true, 'errors' => $this->errors)));
		if ($this->ajax_refresh)
			die(Tools::jsonEncode(array('refresh' => true)));

		if (Tools::getIsset('summary'))
		{
			$result = array();
			if (Configuration::get('PS_ORDER_PROCESS_TYPE') == 1)
			{
				$groups = (Validate::isLoadedObject($this->context->customer)) ? $this->context->customer->getGroups() : array(1);
				if ($this->context->cart->id_address_delivery)
					$deliveryAddress = new Address($this->context->cart->id_address_delivery);
				$id_country = (isset($deliveryAddress) && $deliveryAddress->id) ? $deliveryAddress->id_country : Configuration::get('PS_COUNTRY_DEFAULT');

				Cart::addExtraCarriers($result);
			}
			$result['summary'] = $this->context->cart->getSummaryDetails(null, true);
			$result['customizedDatas'] = Product::getAllCustomizedDatas($this->context->cart->id, null, true);
			$result['HOOK_SHOPPING_CART'] = Hook::exec('displayShoppingCartFooter', $result['summary']);
			$result['HOOK_SHOPPING_CART_EXTRA'] = Hook::exec('displayShoppingCart', $result['summary']);

			foreach ($result['summary']['products'] as $key => &$product)
			{
				$product['quantity_without_customization'] = $product['quantity'];
				if ($result['customizedDatas'] && isset($result['customizedDatas'][(int)$product['id_product']][(int)$product['id_product_attribute']]))
				{
					foreach ($result['customizedDatas'][(int)$product['id_product']][(int)$product['id_product_attribute']] as $addresses)
						foreach ($addresses as $customization)
							$product['quantity_without_customization'] -= (int)$customization['quantity'];
				}
				$product['price_without_quantity_discount'] = Product::getPriceStatic(
					$product['id_product'],
					!Product::getTaxCalculationMethod(),
					$product['id_product_attribute'],
					6,
					null,
					false,
					false
				);
			}
			if ($result['customizedDatas'])
				Product::addCustomizationPrice($result['summary']['products'], $result['customizedDatas']);

			die(Tools::jsonEncode($result));
		}
		// @todo create a hook
		elseif (file_exists(_PS_MODULE_DIR_.'/gc_blockcart/gc_blockcart.ajax.php'))
			require_once(_PS_MODULE_DIR_.'/gc_blockcart/gc_blockcart.ajax.php');
	}
}

