<?php

if (!defined('_PS_VERSION_'))
	exit;

class GC_BlockCart extends Module {
	
	public function __construct() {
		
		$this->name                   = 'gc_blockcart';
		$this->tab                    = 'front_office_features';
		$this->version                = '2.2.2';
		$this->author                 = 'Onlineshop-Module.de';
		$this->need_instance          = 0;
		$this->ps_versions_compliancy = array(
			'min' => '1.5',
			'max' => '1.6'
		);
		
		parent::__construct();

		$this->displayName = $this->l('Cart block');
		$this->description = $this->l('Adds a block containing the customer\'s shopping cart.');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details?');
		
	}
	
	public function install() {
		
		if(Module::isInstalled('blockcart')) {
			
			$this->_errors[] = $this->l('Please deinstall the original module \'blockcart\' first!');
			return false;
			
		}
		
		$return = true;
		
		$return &= parent::install();
		$return &= $this->registerHook('displayTop');
		$return &= $this->registerHook('displayHeader');
		$return &= $this->registerHook('actionCartListOverride');
		
		$return &= Configuration::updateValue('GC_BLOCK_CART_AJAX', 1);
		
		if(!ImageType::typeAlreadyExists('gcblockcart')) {
			
			$image_type = new ImageType();
			$image_type->name = 'gcblockcart';
			$image_type->width = 32;
			$image_type->height = 32; 
			$image_type->products = 1;
			$image_type->categories = 0;
			$image_type->manufacturers = 0;
			$image_type->suppliers = 0;
			$image_type->scenes = 0;
			$image_type->stores = 0;
			
			$return &= $image_type->add();
			
		}
		
		return $return;
		
	}
	
	public function uninstall() {
		
		$return = true;
		
		$return &= Configuration::deleteByName('GC_BLOCK_CART_AJAX');
		
		$image_type = new ImageType('gcblockcart', $this->context->cookie->id_lang);
		
		if(Validate::isLoadedObject($image_type))
			$return &= $image_type->delete();
		
		$return &= parent::uninstall();
		
		return $return;
		
	}
	
	public function getContent() {
		
		$html = '';
		
		$html .= '<img src="'.$this->_path.'logo.png'.'" alt="'.$this->displayName.'" class="float" style="margin:0 20px 20px 0;" />';
		$html .= '<h1>'.$this->displayName.' - '.$this->author.'</h1>';
		$html .= '<p>'.$this->description.'</p>';
		$html .= '<p><a class="link" href="'.$this->_path.'licence.txt" target="_blank">'.$this->l('Please consider our license disclaimer.').'</a></p>';
		
		if($postProcess = $this->postProcess() and !empty($postProcess));
			$postProcess .= '<img src="http://www.onlineshop-module.de/pml.gif?module='.$this->name.'&domain='.$this->context->shop->domain.'&version='.$this->version.'" style="display:none;" />';
		
		$html .= $postProcess;
		
		$html .= $this->displayForm();
		
		return $html;
		
	}
	
	public function postProcess() {
		
		$html = '';
		
		if (Tools::isSubmit('submitGCBlockCart')) {
			
			Configuration::updateValue('GC_BLOCK_CART_AJAX', (bool)Tools::getValue('cart_ajax'));
			
			$html .= $this->displayConfirmation($this->l('Settings updated'));
			
		}
		
		return $html;
		
	}
	
	public function displayForm() {
		
		$html = '';
		
		$html .= '
			<form action="'.Tools::safeOutput($_SERVER['REQUEST_URI']).'" method="post">
				<fieldset>
					<legend>'.$this->l('Settings').'</legend>

					<label>'.$this->l('Ajax cart').'</label>
					<div class="margin-form">
						<input type="radio" name="cart_ajax" id="ajax_on" value="1" '.(Tools::getValue('cart_ajax', Configuration::get('GC_BLOCK_CART_AJAX')) ? 'checked="checked" ' : '').'/>
						<label class="t" for="ajax_on"> <img src="../img/admin/enabled.gif" alt="'.$this->l('Enabled').'" title="'.$this->l('Enabled').'" /></label>
						<input type="radio" name="cart_ajax" id="ajax_off" value="0" '.(!Tools::getValue('cart_ajax', Configuration::get('GC_BLOCK_CART_AJAX')) ? 'checked="checked" ' : '').'/>
						<label class="t" for="ajax_off"> <img src="../img/admin/disabled.gif" alt="'.$this->l('Disabled').'" title="'.$this->l('Disabled').'" /></label>
						<p class="clear">'.$this->l('Activate AJAX mode for cart (compatible with the default theme)').'</p>
					</div>

					<center><input type="submit" name="submitGCBlockCart" value="'.$this->l('Save').'" class="button" /></center>
				</fieldset>
			</form>
		';
		
		return $html;
		
	}

	public function hookDisplayRightColumn($params) {
		
		if (Configuration::get('PS_CATALOG_MODE'))
			return;
		
		$this->assignContentVars($params);
		
		return $this->display(__FILE__, 'displayRightColumn.tpl');
		
	}

	public function hookDisplayLeftColumn($params) {
		
		return $this->hookRightColumn($params);
		
	}

	public function hookDisplayAjaxCall($params) {
		
		if (Configuration::get('PS_CATALOG_MODE'))
			return;

		$this->assignContentVars($params);
		
		return $this->display(__FILE__, 'json.tpl');
		
	}

	public function hookDisplayHeader() {
		
		if (Configuration::get('PS_CATALOG_MODE'))
			return;
		
		$this->context->controller->addCSS(($this->_path).'views/gc_blockcart.css', 'all');
		
		if ((int)(Configuration::get('GC_BLOCK_CART_AJAX')))
			$this->context->controller->addJS(($this->_path).'views/ajax-cart.js');
		
	}
	
	public function hookDisplayTop($params) {
		
		return $this->hookDisplayRightColumn($params);
		
	}
	
	public function hookActionCartListOverride($params) {
		
		if (!Configuration::get('PS_BLOCK_CART_AJAX'))
			return;

		$this->assignContentVars(array('cookie' => $this->context->cookie, 'cart' => $this->context->cart));
		
		$params['json'] = $this->display(__FILE__, 'blockcart-json.tpl');
		
	}
	
	public function assignContentVars(&$params) {
		
		global $errors;

		// Set currency
		if ((int)$params['cart']->id_currency && (int)$params['cart']->id_currency != $this->context->currency->id)
			$currency = new Currency((int)$params['cart']->id_currency);
		else
			$currency = $this->context->currency;

		$taxCalculationMethod = Group::getPriceDisplayMethod((int)Group::getCurrent()->id);

		$useTax = !($taxCalculationMethod == PS_TAX_EXC);

		$products = $params['cart']->getProducts(true);
		$nbTotalProducts = 0;
		foreach ($products as $product)
			$nbTotalProducts += (int)$product['cart_quantity'];
		$cart_rules = $params['cart']->getCartRules();

		$base_shipping = $params['cart']->getOrderTotal($useTax, Cart::ONLY_SHIPPING);
		$shipping_cost = Tools::displayPrice($base_shipping, $currency);
		$shipping_cost_float = Tools::convertPrice($base_shipping, $currency);
		$wrappingCost = (float)($params['cart']->getOrderTotal($useTax, Cart::ONLY_WRAPPING));
		$totalToPay = $params['cart']->getOrderTotal($useTax);

		if ($useTax && Configuration::get('PS_TAX_DISPLAY') == 1)
		{
			$totalToPayWithoutTaxes = Tools::ps_round($params['cart']->getOrderTotal(false), 2);
			$this->smarty->assign('tax_cost', Tools::displayPrice(Tools::ps_round($totalToPay, 2) - $totalToPayWithoutTaxes, $currency));
		}
		
		// The cart content is altered for display
		foreach ($cart_rules as &$cart_rule)
		{
			if ($cart_rule['free_shipping'])
			{
				$shipping_cost = Tools::displayPrice(0, $currency);
				$shipping_cost_float = 0;
				$cart_rule['value_real'] -= Tools::convertPrice($params['cart']->getOrderTotal(true, Cart::ONLY_SHIPPING), $currency);
				$cart_rule['value_tax_exc'] = Tools::convertPrice($params['cart']->getOrderTotal(false, Cart::ONLY_SHIPPING), $currency);
			}
			if ($cart_rule['gift_product'])
			{
				foreach ($products as &$product)
					if ($product['id_product'] == $cart_rule['gift_product'] && $product['id_product_attribute'] == $cart_rule['gift_product_attribute'])
					{
						$product['is_gift'] = 1;
						$product['total_wt'] = Tools::ps_round($product['total_wt'] - $product['price_wt'], (int)$currency->decimals * _PS_PRICE_DISPLAY_PRECISION_);
						$product['total'] = Tools::ps_round($product['total'] - $product['price'], (int)$currency->decimals * _PS_PRICE_DISPLAY_PRECISION_);
						$cart_rule['value_real'] = Tools::ps_round($cart_rule['value_real'] - $product['price_wt'], (int)$currency->decimals * _PS_PRICE_DISPLAY_PRECISION_);
						$cart_rule['value_tax_exc'] = Tools::ps_round($cart_rule['value_tax_exc'] - $product['price'], (int)$currency->decimals * _PS_PRICE_DISPLAY_PRECISION_);
					}
			}
		}
		
		$country_name = '';
		
		if($params['cart']->id_address_delivery) {
			$address = New Address($params['cart']->id_address_delivery);
			$country_name = $address->country;
		}
		else {
			$country = new Country(Configuration::get('PS_COUNTRY_DEFAULT'), $this->context->cookie->id_lang);
			$country_name = $country->name;
		}
		
		$this->smarty->assign(array(
			'products' => $products,
			'customizedDatas' => Product::getAllCustomizedDatas((int)($params['cart']->id)),
			'CUSTOMIZE_FILE' => _CUSTOMIZE_FILE_,
			'CUSTOMIZE_TEXTFIELD' => _CUSTOMIZE_TEXTFIELD_,
			'discounts' => $cart_rules,
			'nb_total_products' => (int)($nbTotalProducts),
			'shipping_cost' => $shipping_cost,
			'shipping_cost_float' => $shipping_cost_float,
			'show_wrapping' => $wrappingCost > 0 ? true : false,
			'show_tax' => (int)(Configuration::get('PS_TAX_DISPLAY') == 1 && (int)Configuration::get('PS_TAX')),
			'wrapping_cost' => Tools::displayPrice($wrappingCost, $currency),
			'product_total' => Tools::displayPrice($params['cart']->getOrderTotal($useTax, Cart::BOTH_WITHOUT_SHIPPING), $currency),
			'total' => Tools::displayPrice($totalToPay, $currency),
			'order_process' => Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc' : 'order',
			'ajax_allowed' => (int)(Configuration::get('PS_BLOCK_CART_AJAX')) == 1 ? true : false,
			'static_token' => Tools::getToken(false),
			'country_name' => $country_name,
			'shipping_cms_id' => Configuration::get('GC_CMS_ID_SHIPPING')
		));
		
		$payment_cost = 0;
		$payment_name = '';
		
		if(Module::isEnabled('gc_payment')) {
			$payment_cost = $params['cart']->getOrderTotal($useTax, Cart::ONLY_PAYMENT);
			$payment_name = Payment::getPaymentTitle();
		}
		
		$this->smarty->assign(array(
			'payment_cost_float' => Tools::convertPrice($payment_cost, $currency),
			'payment_cost' => Tools::displayPrice($payment_cost, $currency),
			'payment_name' => $payment_name
		));
		
		if (count($errors))
			$this->smarty->assign('errors', $errors);
		
	}
	
	public function checkOverrides() {
		
		$errors = array();
		
		foreach (Tools::scandir($this->getLocalPath().'override', 'php', '', true) as $file) {
			$class = basename($file, '.php');
			if (Autoload::getInstance()->getClassPath($class.'Core') and $error = $this->checkOverride($class))
				$errors[] = $error;
		}
		
		return $errors;
		
	}
	
	public function checkOverride($classname) {
		
		$path = Autoload::getInstance()->getClassPath($classname.'Core');

		// Check if there is already an override file
		if (!($classpath = Autoload::getInstance()->getClassPath($classname))) {
			
			$override_dest = _PS_ROOT_DIR_.DIRECTORY_SEPARATOR.'override'.DIRECTORY_SEPARATOR.$path;
			
			if (!is_writable(dirname($override_dest)))
				return sprintf(Tools::displayError('directory (%s) not writable'), dirname($override_dest));
			
			return '';
			
		}
		
		// Check if override file is writable
		$override_path = _PS_ROOT_DIR_.'/'.Autoload::getInstance()->getClassPath($classname);
		
		// Get a uniq id for the class, because you can override a class (or remove the override) twice in the same session and we need to avoid redeclaration
		do $uniq = uniqid();
		while (class_exists($classname.'OverrideOriginal'.$uniq, false));
		
		if (!is_writable($override_path))
			return sprintf(Tools::displayError('file (%s) not writable'), $override_path);
		
		// Make a reflection of the override class and the module override class
		$override_file = file($override_path);
		eval(preg_replace(array('#^\s*<\?php#', '#class\s+'.$classname.'\s+extends\s+([a-z0-9_]+)(\s+implements\s+([a-z0-9_]+))?#i'), array('', 'class '.$classname.'OverrideOriginal'.$uniq), implode('', $override_file)));
		$override_class = new ReflectionClass($classname.'OverrideOriginal'.$uniq);

		$module_file = file($this->getLocalPath().'override'.DIRECTORY_SEPARATOR.$path);
		eval(preg_replace(array('#^\s*<\?php#', '#class\s+'.$classname.'(\s+extends\s+([a-z0-9_]+)(\s+implements\s+([a-z0-9_]+))?)?#i'), array('', 'class '.$classname.'Override'.$uniq), implode('', $module_file)));
		$module_class = new ReflectionClass($classname.'Override'.$uniq);

		// Check if none of the methods already exists in the override class
		foreach ($module_class->getMethods() as $method)
			if ($override_class->hasMethod($method->getName()))
				return sprintf(Tools::displayError('The method %1$s in the class %2$s is already overriden.'), $method->getName(), $classname);

		// Check if none of the properties already exists in the override class
		foreach ($module_class->getProperties() as $property)
			if ($override_class->hasProperty($property->getName()))
				return sprintf(Tools::displayError('The property %1$s in the class %2$s is already defined.'), $property->getName(), $classname);
		
		return '';
		
	}
	
	public function deleteOverride($classname, $function) {
		
		if (!Autoload::getInstance()->getClassPath($classname))
			return true;

		// Check if override file is writable
		$override_path = _PS_ROOT_DIR_.'/'.Autoload::getInstance()->getClassPath($classname);
		if (!is_writable($override_path))
			return false;

		// Make a reflection of the override class and the module override class
		$override_file = file($override_path);
		eval(preg_replace(array('#^\s*<\?php#', '#class\s+'.$classname.'\s+extends\s+([a-z0-9_]+)(\s+implements\s+([a-z0-9_]+))?#i'), array('', 'class '.$classname.'OverrideOriginal_delete'), implode('', $override_file)));
		$override_class = new ReflectionClass($classname.'OverrideOriginal_delete');

		// Remove methods from override file
		$override_file = file($override_path);
		
		if (!$override_class->hasMethod($function))
			return false;

		$method = $override_class->getMethod($function);
		$length = $method->getEndLine() - $method->getStartLine() + 1;
		array_splice($override_file, $method->getStartLine() - 1, $length, array_pad(array(), $length, '#--remove--#'));

		// Rewrite nice code
		$code = '';
		
		foreach ($override_file as $line)
		{
			if ($line == '#--remove--#')
				continue;

			$code .= $line;
		}
		
		file_put_contents($override_path, $code);

		return true;
		
	}
	
}

