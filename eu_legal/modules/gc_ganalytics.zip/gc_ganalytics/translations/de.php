<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_aba1a7971f85c725ba4aed21343eeb4b'] = 'Integriert Google Analytics in den Shop';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_fa214007826415a21a8456e3e09f999d'] = 'Wollen Sie wirklich die Einstellungen löschen?';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_7510f8b22dd3e10476096425f78d4239'] = 'Sie haben noch keine Google Analytics ID eingetragen.';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_c5a409deff5fae566d801d22c02e3f0e'] = 'Ihre Google Analytics ID hat ein falsches format.';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_e8ec1f9896aea171e1bbae539e6ceb01'] = 'Die Side Speed Sample Rate muss zwischen 0 und 100 liegen';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen gespeichert';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_d8d9b1b4a682b672372d74dfccd04d68'] = 'Analytics ID';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_81eeab9506186e2dca8faefa78d54067'] = 'Beispiel:';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_5e240a6538ca5f40c6f59001991fae6b'] = 'Side Speed Sample Rate';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_0bcef9c45bd8a48eda1b26eb0c61c869'] = '%';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_ce6a82a961b6dfdae72ec3a61a5d9009'] = 'Diese Einstellung bestimmt, wie oft das Side Speed Tracking pro 100 Besucher ausgeführt wird in Prozent (%)';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_4a5ba63d40c8557b5cce1ca034a2154d'] = 'Button Tracking';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_f38f5f7e108447df47ac560df4d54129'] = '\"Add to Cart\" Buttons werden mit in die Auswertung eingebunden.';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_bd98359c67752644d806b430d13b5de3'] = 'IP Anonymisieren';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_6e14f89151ae87f695d525b91bea3e66'] = 'Die IP Adresse wird anonymisiert. Wichtig für den Betrieb in Deutschland.';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_2a8fa8eb52f92d7846f1e9efb62e99e3'] = 'Tracking ausschließen';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_1929dbcacfa492ef091407027a4488c9'] = 'Setzen Sie diesen Link in Ihre Datenschutz CMS Seite. Damit können die Kunden sich vom Tracking ausschließen.';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{gc_ganalytics}prestashop>gc_ganalytics_e1d6eb91fc48725f18b142d71a7dae3e'] = 'Achtung: Einige Funktionen von gc_ganalytics werden nicht in Kombination mit blockcart funktionieren. Bitte installieren Sie stattdessen das gc_blockcart Modul.';
