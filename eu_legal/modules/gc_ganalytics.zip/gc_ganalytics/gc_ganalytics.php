<?php

/**
 * 
 * GC Google Analytics
 * Module for Prestashop E-Commerce Software
 * 
 * @description PrestaShop module for google analytics
 * @author      Markus Engel <info@onlineshop-module.de>
 * @copyright   Copyright (c) 2014, Onlineshop-Module.de
 * @license     commercial, see licence.txt
 *
 */

if (!defined('_PS_VERSION_'))
	exit;

class GC_Ganalytics extends Module {
	
	function __construct() {
	 	
		$this->name          = 'gc_ganalytics';
	 	$this->tab           = 'analytics_stats';
	 	$this->version       = '2.3.0';
		$this->author        = 'Onlineshop-Module.de';
		$this->need_instance = 1;
		$this->bootstrap     = true;
		$this->ps_versions_compliancy = array(
			'min' => '1.5',
			'max' => '1.6'
		);
		
	 	parent::__construct();
		
		$this->displayName      = $this->l('Google Analytics');
		$this->description      = $this->l('Integrate Google Analytics script into your shop');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details ?');
		
		if($this->id && !Configuration::get('GC_GANALYTICS_ID'))
			$this->warning = $this->l('You have not yet set your Google Analytics ID');
		
		//$this->checkDependencies();
		
	}

	function install() {
		
		$return = true;
		
		$return &= parent::install();
		
		$return &= $this->registerHook('displayHeader');
		$return &= $this->registerHook('displayOrderConfirmation');
		
		$return &= Configuration::updateValue('GC_GANALYTICS_ID', '');
		$return &= Configuration::updateValue('GC_GANALYTICS_SSSR', 50);
		$return &= Configuration::updateValue('GC_GANALYTICS_TB', true);
		$return &= Configuration::updateValue('GC_GANALYTICS_AIP', true);
		
		return (bool)$return;
		
	}

	function uninstall() {
		
		$return = true;
		
		$return &= Configuration::deleteByName('GC_GANALYTICS_ID');
		$return &= Configuration::deleteByName('GC_GANALYTICS_SSSR');
		$return &= Configuration::deleteByName('GC_GANALYTICS_TB');
		$return &= Configuration::deleteByName('GC_GANALYTICS_AIP');
		
		$return &= parent::uninstall();
		
		return (bool)$return;
		
	}

	public function getContent() {
		
		$html = '';
		
		$html .= $this->displayInfo();
		
		if($postProcess = $this->postProcess() and !empty($postProcess));
			$postProcess .= '<img src="http://www.onlineshop-module.de/pml.gif?module='.$this->name.'&domain='.$this->context->shop->domain.'&version='.$this->version.'" style="display:none;" />';
		
		$html .= $postProcess;
		
		$html .= $this->displayOptions();
		
		return $html;
		
	}
	
	public function displayInfo() {
		
		$this->smarty->assign(array(
			'_path' =>		 $this->_path,
			'displayName' => $this->displayName,
			'author' =>      $this->author,
			'description' => $this->description,
		));
		 
		return $this->display(__FILE__, 'views/templates/module/info.tpl');
		
	}
	
	public function postProcess() {
		
		if(Tools::isSubmit('submitGCGanalytics')) {
			
			if(!$ganalytics_id = Tools::getValue('GC_GANALYTICS_ID') or !preg_match('#UA-[0-9]{5,10}-[0-9]{1,3}#', $ganalytics_id))
				return $this->displayError($this->l('Your Google Analytics ID has a incorrect format.'));
			
			if(!$ganalytics_sssr = (int)Tools::getValue('GC_GANALYTICS_SSSR') or $ganalytics_sssr < 0 or $ganalytics_sssr > 100)
				return $this->displayError($this->l('The Side Speed Sample Rate mus be a value between 0 and 100'));
			
			Configuration::updateValue('GC_GANALYTICS_ID', $ganalytics_id);
			Configuration::updateValue('GC_GANALYTICS_SSSR', $ganalytics_sssr);
			Configuration::updateValue('GC_GANALYTICS_TB', (bool)Tools::getValue('GC_GANALYTICS_TB'));
			Configuration::updateValue('GC_GANALYTICS_AIP', (bool)Tools::getValue('GC_GANALYTICS_AIP'));
			
			return $this->displayConfirmation($this->l('Settings updated'));
			
		}
		
	}

	public function displayOptions() {
		
		$html = '';
		
		/*
		if($warning = $this->checkDependencies())
			$html .= '<div class="warning">'.$warning.'</div>';
		*/
		
		$fields_options = array(
			array(
				'title' => $this->l('Settings'),
				'fields' => array(
					'GC_GANALYTICS_ID' => array(
						'title' => $this->l('Analytics ID'),
						'type' => 'text',
						'desc' => $this->l('Example:').' UA-1234567-1',
					),
					'GC_GANALYTICS_SSSR' => array(
						'title' => $this->l('Side Speed Sample Rate'),
						'type' => 'text',
						'size' => 3,
						'suffix' => $this->l('%'),
						'desc' => $this->l('This setting determines how often site speed tracking beacons will be sent in percent (%)'),
					),
					'GC_GANALYTICS_TB' => array(
						'title' => $this->l('Track Buttons'),
						'type' => 'bool',
						'desc' => $this->l('Track "Add to Cart" buttons'),
					),
					'GC_GANALYTICS_AIP' => array(
						'title' => $this->l('Anonymice IP'),
						'type' => 'bool',
						'desc' => $this->l('Anonymice the IP address.'),
					),
					'ExcludeTracking' => array(
						'title' => $this->l('Exclude Tracking'),
						'type' => 'html',
						'auto_value' => false,
						'value' => '<a href="?exclude_analytics=1" id="ganalytics_exclude">Exclude me from Google Analytics tracking!</a>',
						'desc' => $this->l('Insert this link in your privacy policy cms page. With this users can exclude their tracking.'),
					),
				),
				'submit' => array(
					'name' => 'submitGCGanalytics',
					'title' => $this->l('Save'),
				),
			),
		);
		
		$helper = new HelperOptions();
		
		$helper->id = Tab::getIdFromClassName('AdminModules');
		$helper->default_form_language = $this->context->cookie->id_lang;
		$helper->show_toolbar = true;
		$helper->module = $this;
		$helper->title = $this->displayName;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		
		return $helper->generateOptions($fields_options);
		
	}
	
	public function assignParameter() {
		
		$controller = basename(Tools::getValue('controller'));
		
		if($controller == 'order' or $controller == 'gcorder')
			$page_track = '/order/step'.(int)Tools::getValue('step').'.html';
		elseif($controller == 'authentication' and Tools::getIsset('display_guest_checkout'))
			$page_track = '/order/step1_auth.html';
		else
			$page_track = false;
		
		$this->context->smarty->assign(array(
			'ganalytics_id'   => Configuration::get('GC_GANALYTICS_ID'),
			'track_buttons'   => (int)Configuration::get('GC_GANALYTICS_TB'),
			'anonymice_ip'    => (int)Configuration::get('GC_GANALYTICS_AIP'),
			'ganalytics_sssr' => (int)Configuration::get('GC_GANALYTICS_SSSR'),
			'page_track'      => $page_track,
		));
		
	}
	
	public function hookDisplayHeader($params) {
		
		if(!$this->isActive())
			return;
		
		if(($exclude_analytics = Tools::getValue('exclude_analytics')) !== false and Validate::isBool($exclude_analytics)) {
			$this->context->cookie->exclude_analytics = $exclude_analytics;
		}
		
		if(isset($this->context->cookie->exclude_analytics) and $this->context->cookie->exclude_analytics)
			return '';
		
		$this->assignParameter();
		
		$this->context->smarty->assign('is_order', false);
		
		return $this->display(__FILE__, 'displayHeader.tpl');
		
	}
	
	public function hookDisplayFooter($params) {
		
		if($this->isRegisteredInHook('displayHeader'))
			return '';
		
		return $this->hookDisplayHeader($params);
		
	}

	public function hookDisplayOrderConfirmation($params) {
		
		if(!$this->isActive())
			return;
		
		if(isset($this->context->cookie->exclude_analytics) and $this->context->cookie->exclude_analytics)
			return '';

		$order = $params['objOrder'];
		
		$this->assignParameter();
		
		if (Validate::isLoadedObject($order))
		{
			$delivery_address = new Address($order->id_address_delivery);

			$conversion_rate = 1;
			$currency = new Currency($order->id_currency);
			
			if ($order->id_currency != Configuration::get('PS_CURRENCY_DEFAULT'))
				$conversion_rate = (float)$currency->conversion_rate;

			// Order general information
			$state_name = '';
			if($delivery_address->id_state and $state = new State($delivery_address->id_state) and Validate::isLoadedObject($state))
				$state_name = $state->name;
			
			$trans = array(
				'id'       => (int)$order->id,
				'store'    => htmlentities($this->context->shop->name),
				'total'    => Tools::ps_round((float)$order->total_paid_tax_incl / $conversion_rate, 2),
				'tax'      => Tools::ps_round((((float)$order->total_paid_tax_incl - (float)$order->total_discounts_tax_excl) / $conversion_rate), 2),
				'shipping' => Tools::ps_round((float)$order->total_shipping / $conversion_rate, 2),
				'city'     => addslashes($delivery_address->city),
				'state'    => $state_name,
				'country'  => addslashes($delivery_address->country),
				'currency' => $currency->iso_code
			);

			// Product information
			$products = $order->getProducts();
			$items = array();
			
			foreach($products AS $product) {
				
				$category = Db::getInstance()->getRow('
					SELECT name FROM `'._DB_PREFIX_.'category_lang` , '._DB_PREFIX_.'product
					WHERE `id_product` = '.$product['product_id'].' AND `id_category_default` = `id_category`
					AND `id_lang` = \''.$order->id_lang.'\'
				');

				$items[] = array(
					'OrderId'  => (int)$order->id,
					'SKU'      => addslashes($product['product_id'].'_'.$product['product_attribute_id']),
					'Product'  => addslashes($product['product_name']),
					'Category' => addslashes($category['name']),
					'Price'    => Tools::ps_round((float)$product['product_price_wt'] / $conversion_rate, 2),
					'Quantity' => addslashes((int)$product['product_quantity'])
				);
				
			}
			
			$this->context->smarty->assign('is_order', true);

			$this->context->smarty->assign(array(
				'items'         => $items,
				'trans'         => $trans
			));
			
			return $this->display(__FILE__, 'displayHeader.tpl');
			
		}
		
	}
	
	public function checkDependencies() {
		
		$blockcart = Module::getInstanceByName('blockcart');
		
		if($blockcart and Validate::isLoadedObject($blockcart))
			return $this->warning = $this->l('Please be carefull: Some functions of gc_ganalytics will not work with blockcart. Please install the gc_blockcart module instead.');
		
	}
	
	public function isActive() {
		
		$active = true;
		
		$active &= $this->active;
		$active &= (bool)Configuration::get('GC_GANALYTICS_ID');
		
		return $active;
		
	}
	
}
