<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcms}prestashop>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{blockcms}prestashop>blockcms_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{blockcms}prestashop>blockcms_ef61fb324d729c341ea8ab9901e23566'] = 'Add new';
$_MODULE['<{blockcms}prestashop>blockcms_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockcms}prestashop>blockcms_965be994da393e5aa15bd3a2444c6ccf'] = 'Footer\'s various links Configuration';
$_MODULE['<{blockcms}prestashop>blockcms_9aa03a5dca2e060a4ecbff0dd8616692'] = 'Save';
$_MODULE['<{blockcms}prestashop>blockcms_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{blockcms}prestashop>blockcms_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blockcms}prestashop>blockcms_87a2663d841b78f01c27c0edb4f50b76'] = 'Deletion successful';
$_MODULE['<{blockcms}prestashop>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Our stores';
$_MODULE['<{blockcms}prestashop>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Best sellers';
$_MODULE['<{blockcms}prestashop>blockcms_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';
$_MODULE['<{blockcms}prestashop>form_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blockcms}prestashop>form_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Position';
$_MODULE['<{blockcms}prestashop>form_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
$_MODULE['<{blockcms}prestashop>form_08a38277b0309070706f6652eeae9a53'] = 'Down';
$_MODULE['<{blockcms}prestashop>form_258f49887ef8d14ac268c92b02503aaa'] = 'Up';
$_MODULE['<{blockcms}prestashop>form_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{blockcms}prestashop>form_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{blockcms}prestashop>form_49ee3087348e8d44e1feda1917443987'] = 'Name';
