<?php

class GC_NewsletterVerificationModuleFrontController extends ModuleFrontController {
	
	private $message = '';
	
	public function postProcess() {
		
		$this->message = $this->module->confirmEmail(Tools::getValue('hash'));
		
	}
	
	public function initContent() {
		
		parent::initContent();

		$this->context->smarty->assign('message', $this->message);
		$this->setTemplate('verification.tpl');
		
	}
	
}
