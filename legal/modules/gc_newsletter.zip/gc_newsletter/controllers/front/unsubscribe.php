<?php

class GC_NewsletterUnsubscribeModuleFrontController extends ModuleFrontController {
	
	private $message = '';
	
	public function postProcess() {
		
		$this->message = $this->module->unsubscribeEmail(Tools::getValue('hash'));
		
	}
	
	public function initContent() {
		
		parent::initContent();

		$this->context->smarty->assign('message', $this->message);
		$this->setTemplate('unsubscribe.tpl');
		
	}
	
}
