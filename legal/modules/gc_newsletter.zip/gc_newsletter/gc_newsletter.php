<?php

if (!defined('_PS_VERSION_'))
	exit;

class GC_Newsletter extends Module {
	
	const NOT_REGISTERED = 0;
	const VISITOR_REGISTERED = 1;
	const GUEST_REGISTERED = 2;
	const CUSTOMER_REGISTERED = 3;
	
	public function __construct() {
		
		$this->name          = 'gc_newsletter';
		$this->tab           = 'front_office_features';
		$this->version       = '2.0.3';
		$this->author        = 'Onlineshop-Module.de';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array(
			'min' => '1.5.5.0',
			'max' => '1.6'
		);
		$this->dependencies = array('gc_german');
		
		parent::__construct();

		$this->displayName = $this->l('Newsletter');
		$this->description = $this->l('Adds a block for newsletter subscription.');
		$this->confirmUninstall = $this->l('Are you sure that you want to delete all of your contacts?');
		
		$this->error = false;
		$this->valid = false;
		
		if($original = Module::getInstanceByName('blocknewsletter') and Validate::isLoadedObject($original) and $original->active)
			$this->warning = $this->l('Caution: Original blocknewsletter module still active!');
		
		if ($this->id) {
			
			$this->_file = 'export_'.$this->getHash(Configuration::get('PS_SHOP_EMAIL')).'.csv';
			$this->_postValid = array();
			
			$array_countries = array();
			$array_groups = array();
			$array_zones = array();
			
			$countries = Country::getCountries($this->context->language->id);
			$groups = Group::getGroups($this->context->language->id);
			$zones = Zone::getZones($this->context->language->id);
			
			$array_countries[0] = $this->l('All countries');
			$array_groups[0] = $this->l('All groups');
			$array_zones[0] = $this->l('All zones');
			
			foreach ($countries as $country)
				$array_countries[$country['id_country']] = $country['name'];
			
			foreach ($groups as $group)
				$array_groups[$group['id_group']] = $group['name'];
			
			foreach ($zones as $zone)
				$array_zones[$zone['id_zone']] = $zone['name'];
			
			// And filling fields to show !
			$this->_fieldsExport = array(
				'GROUP' => array(
					'title' => $this->l('Customer Group'),
					'desc' => $this->l('Filter customer group'),
					'type' => 'select',
					'value' => $array_groups,
					'value_default' => 0
				),
				'CART' => array(
					'title' => $this->l('Broken cart'),
					'desc' => $this->l('All carts without orders'),
					'type' => 'checkbox',
					'value' => 1,
					'value_default' => 0
				),
				'COUNTRY' => array(
					'title' => $this->l('Customers country'),
					'desc' => $this->l('Operate a filter on customers country.'),
					'type' => 'select',
					'value' => $array_countries,
					'value_default' => 0
				),
				'ZONE' => array(
					'title' => $this->l('Customers zone'),
					'desc' => $this->l('Customers with zones'),
					'type' => 'select',
					'value' => $array_zones,
					'value_default' => 0
				),
				'DATEADD' => array(
					'title' => $this->l('Subscribe date'),
					'desc' => $this->l('Filter date subscribe'),
					'type' => 'date',
					'value_default' => array(date('Y-m-d', time()-60*60*24*31), date('Y-m-d'))
				),
				'MERGECUSTOMER' => array(
					'title' => $this->l('Merge Customers'),
					'desc' => $this->l('Merge customer email adresses if not registered newsletter'),
					'type' => 'bool',
					'default' => 0
				),
				'ONLYDBLOPTIN' => array(
					'title' => $this->l('Only Doubleoptin'),
					'desc' => $this->l('Only subscribers with double optin enabled.'),
					'type' => 'bool',
					'default' => 1
				),
				'DELETED' => array(
					'title' => $this->l('Deleted Subscribers'),
					'desc' => $this->l('Include deleted subscribers.'),
					'type' => 'bool',
					'default' => 0
				),
			);
		}
		
	}

	public function install() {
		
		if(!parent::install())
			return false;
		
		$return = true;
		
		// Don't uninstall block newsletter if already installed. Just deactivate!
		if($original = Module::getInstanceByName('blocknewsletter') and Validate::isLoadedObject($original)) {
			$original->disable(true);
		}
		
		// Deinstall newsletter (csv export) module
		if($original = Module::getInstanceByName('newsletter') and Validate::isLoadedObject($original)) {
			$original->uninstall();
		}
		
		$return &= $this->registerHook('displayLeftColumn');
		$return &= $this->registerHook('actionNewsletter');
		
		$return &= Configuration::updateValue('NW_SALT', Tools::passwdGen(16));
		
		$return &= Db::getInstance()->execute('
			CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'newsletter` (
				`id` int(6) NOT NULL AUTO_INCREMENT,
				`id_shop` INTEGER UNSIGNED NOT NULL DEFAULT \'1\',
				`id_shop_group` INTEGER UNSIGNED NOT NULL DEFAULT \'1\',
				`email` varchar(255) NOT NULL,
				`newsletter_date_add` DATETIME NULL,
				`ip_registration_newsletter` varchar(15) NOT NULL,
				`http_referer` VARCHAR(255) NULL,
				`active` TINYINT(1) NOT NULL DEFAULT \'0\',
				PRIMARY KEY(`id`)
			) ENGINE='._MYSQL_ENGINE_.' default CHARSET=utf8
		');
		
		$return &= Db::getInstance()->execute('
			ALTER TABLE `'._DB_PREFIX_.'newsletter`
			ADD `hash` VARCHAR( 64 ) NOT NULL,
			ADD `date_dbloptin` DATETIME NULL,
			ADD `date_deleted` DATETIME NULL,
			ADD `date_add` DATETIME NULL,
			ADD `date_upd` DATETIME NULL,
			ADD `id_customer` INTEGER UNSIGNED NOT NULL DEFAULT \'0\',
			ADD UNIQUE (`email`)
		');
		
		$now = date('Y-m-d H:i:s');
		
		$result = Db::getInstance()->executeS("
			SELECT id_customer, email, id_shop, id_shop_group, ip_registration_newsletter, newsletter_date_add, active, deleted FROM `"._DB_PREFIX_."customer`
			WHERE `newsletter` = '1'
			GROUP BY email
		");
		
		foreach($result as $row)
			$return &= Db::getInstance()->execute("
				REPLACE INTO `"._DB_PREFIX_."newsletter` SET 
				id_shop='".$row['id_shop']."',
				id_shop_group='".$row['id_shop_group']."',
				id_customer='".$row['id_customer']."',
				email='".$row['email']."',
				newsletter_date_add='".$row['newsletter_date_add']."',
				ip_registration_newsletter='".$row['ip_registration_newsletter']."',
				active='".$row['active']."'
				".($row['deleted']==1 ? ",date_deleted='".$row['date_upd']."'" : "")."
			");
		
		$return &= Db::getInstance()->execute("
			UPDATE `"._DB_PREFIX_."newsletter`
			SET `hash`=MD5(CONCAT(email, '"._COOKIE_KEY_."')), `date_add`='".$now."', `date_upd`='".$now."'
		");
		
		return $return;
		
	}

	public function uninstall() {
		
		$return = true;
		
		$return &= Db::getInstance()->execute('DROP TABLE '._DB_PREFIX_.'newsletter');
		
		$return &= parent::uninstall();
		
		return $return;
		
	}

	public function getContent() {
		
		$html = '';
		
		$html .= '<img src="'.$this->_path.'logo.png'.'" alt="'.$this->displayName.'" class="float" style="margin:0 20px 20px 0;" />';
		$html .= '<h1>'.$this->displayName.' - '.$this->author.'</h1>';
		$html .= '<p>'.$this->description.'</p>';
		$html .= '<p><a class="link" href="'.$this->_path.'licence.txt" target="_blank">'.$this->l('Please consider our license disclaimer.').'</a></p>';
		
		if($postProcess = $this->postProcess() and !empty($postProcess));
			$postProcess .= '<img src="http://www.onlineshop-module.de/pml.gif?module='.$this->name.'&domain='.$this->context->shop->domain.'&version='.$this->version.'" style="display:none;" />';
		
		$html .= $postProcess;
		
		$html .= $this->displayForm();
		
		return $html;
		
	}
	
	public function postProcess() {
		
		$return = false;
		
		if(Tools::isSubmit('submitUpdate')) {
			
			$return = true;
			
			Configuration::updateValue('NW_CONFIRMATION_EMAIL', pSQL($_POST['conf_email']))
				|| $this->_errors[] = $this->l('Could not update NW_CONFIRMATION_EMAIL');
			
			Configuration::updateValue('NW_VERIFICATION_EMAIL', (int)$_POST['verif_email'])
				|| $this->_errors[] = $this->l('Could not update NW_VERIFICATION_EMAIL');
			
			Configuration::updateValue('NW_VOUCHER_CODE', pSQL($_POST['voucher']))
				|| $this->_errors[] = $this->l('Could not update NW_VOUCHER_CODE');
			
			return $this->displayConfirmation($this->l('Settings updated.'));
			
		}
		elseif(Tools::isSubmit('submitExport')) {
			
			$return = true;
			
			$result = $this->getExportNewsletter();
			
			if (!$nb = (int)(Db::getInstance(_PS_USE_SQL_SLAVE_)->NumRows()))
				$this->_errors[] = $this->l('No customers found with these filters!');
			elseif ($fd = @fopen(dirname(__FILE__).'/'.$this->_file, 'w')) {
				
				foreach ($result AS $tab)
					$this->fputcsv($fd, $tab);
				
				fclose($fd);
				
				return $this->displayConfirmation(
					sprintf($this->l('The .CSV file has been successfully exported. (%d customers found)'), $nb).'<br />
					<a href="../modules/gc_newsletter/'.$this->_file.'"><b>'.$this->l('Download the file').' '.$this->_file.'</b></a>
					<br />
					<ol style="margin-top: 10px;">
						<li style="color: red;">'.$this->l('WARNING: If opening this .csv file with Excel, remember to choose UTF-8 encoding or you may see strange characters.').'</li>
					</ol>'
				);
			}
			else
				$this->_errors[] = $this->l('Error: cannot write').' '.dirname(__FILE__).'/'.$this->_file.' !';
			
		}
		
		if(count($this->_errors))
			return $this->displayError(implode('<br />', $this->_errors));
		
	}
	
	public function displayForm() {
		
		$html = '';
		
		$html .= '
			<form action="'.$this->getModuleBOLink().'" method="post">
				<fieldset>
					<legend>'.$this->l('Export customers').'</legend>
					
					<p>'.$this->l('Generate a .CSV file from newsletter data.').'</p>
		';
					
		foreach ($this->_fieldsExport as $key => $field) {
			
			$html .= '
					<label>'.$field['title'].':</label>
					<div class="margin-form">
			';
			
			switch ($field['type']) {
				
				case 'select':
					
					$html .= '<select size="5" multiple name="'.$key.'[]">';
					
					foreach ($field['value'] AS $k => $value) {
						
						$values = Tools::getValue($key, array($field['value_default']));
						$selected = in_array($k, $values);
						
						$html .= '<option value="'.$k.'"'.($selected ? ' selected="selected"' : '').'>'.$value.'</option>';
					}
					
					$html .= '</select>';
					
					break;
				
				case 'checkbox':
					
					$html .= '<input type="checkbox" name="'.$key.'" value="'.$field['value'].'"'.($k = Tools::getValue($key, $field['value_default']) ? ' checked="checked"' : '').' />';
					
					break;
				
				case 'date':
					
					$html .= '<input type="date" name="'.$key.'_FROM" value="'.Tools::getValue($key.'_FROM', $field['value_default'][0]).'" /> - <input type="date" name="'.$key.'_TO" value="'.Tools::getValue($key.'_TO', $field['value_default'][1]).'" />';
					
					break;
				
				case 'bool':
					
					$html .= '
						<input type="radio" name="'.$key.'" id="'.$key.'_ON" value="1" '.(Tools::getValue($key, $field['default']) ? 'checked="checked" ' : '').'/><img src="../img/admin/enabled.gif" alt="'.$this->l('enabled').'" />&nbsp;
						<input type="radio" name="'.$key.'" id="'.$key.'_OFF" value="0" '.(!Tools::getValue($key, $field['default']) ? 'checked="checked" ' : '').'/><img src="../img/admin/disabled.gif" alt="'.$this->l('disabled').'" />';
					
					break;
					
				default:
					break;
				
			}
			
			if (isset($field['desc']) AND !empty($field['desc']))
				$html .= '<p>'.$field['desc'].'</p>';
			
			$html .= '
					</div>
			';
		}
				$html .= '
					<div class="margin-form">
						<input type="submit" class="button" name="submitExport" value="'.$this->l('Export .CSV file').'" />
					</div>
				</fieldset>
			</form>
			<div class="clear">&nbsp;</div>
			
			<form method="post" action="'.$this->getModuleBOLink().'">
				<fieldset>
					<legend>'.$this->l('Settings').'</legend>
					
					<label>'.$this->l('Double-Optin').'</label>
					<div class="margin-form">
						<input type="radio" name="verif_email" id="verif_email_on" value="1" '.(Configuration::get('NW_VERIFICATION_EMAIL') ? 'checked="checked" ' : '').'/>
						<label class="t" for="verif_email_on"> <img src="../img/admin/enabled.gif" alt="'.$this->l('Enabled').'" title="'.$this->l('Enabled').'" /></label>
						<input type="radio" name="verif_email" id="verif_email_off" value="0" '.(!Configuration::get('NW_VERIFICATION_EMAIL') ? 'checked="checked" ' : '').'/>
						<label class="t" for="verif_email_off"> <img src="../img/admin/disabled.gif" alt="'.$this->l('Disabled').'" title="'.$this->l('Disabled').'" /></label>
						<p>'.$this->l('Would you like to send a verification email after subscription?').'</p>
					</div>
					<div class="clear"></div>
					
					<label>'.$this->l('Confirmation').'</label>
					<div class="margin-form">
						<input type="radio" name="conf_email" id="conf_email_on" value="1" '.(Configuration::get('NW_CONFIRMATION_EMAIL') ? 'checked="checked" ' : '').'/>
						<label class="t" for="conf_email_on"> <img src="../img/admin/enabled.gif" alt="'.$this->l('Enabled').'" title="'.$this->l('Enabled').'" /></label>
						<input type="radio" name="conf_email" id="conf_email_off" value="0" '.(!Configuration::get('NW_CONFIRMATION_EMAIL') ? 'checked="checked" ' : '').'/>
						<label class="t" for="conf_email_off"> <img src="../img/admin/disabled.gif" alt="'.$this->l('Disabled').'" title="'.$this->l('Disabled').'" /></label>
						<p>'.$this->l('Would you like to send a confirmation email after subscription?').'</p>
					</div>
					<div class="clear"></div>
					
					<label>'.$this->l('Welcome voucher code').'</label>
					<div class="margin-form">
						<input type="text" name="voucher" value="'.Configuration::get('NW_VOUCHER_CODE').'" />
						<p>'.$this->l('Leave blank to disable by default.').'</p>
					</div>
					
					<div class="margin-form clear pspace">
						<input type="submit" name="submitUpdate" value="'.$this->l('Update').'" class="button" />
					</div>
					
				</fieldset>
			</form>
		';

		return $html;
		
	}

	/**
	 * Check if this mail is registered for newsletters
	 *
	 * @param unknown_type $customerEmail
	 * @return int
	 *   0 = not registered
	 *   1 = visitor registered
	 *   2 = guest registered
	 * 	 3 = customer registerd
	 */
	private function isNewsletterRegistered($email) {
		
		$result = Db::getInstance()->getRow("
			SELECT n.`email`, n.`id_customer`, c.`is_guest`
			FROM `"._DB_PREFIX_."newsletter` AS n
			LEFT JOIN `"._DB_PREFIX_."customer` AS c ON (n.`id_customer` = c.`id_customer`)
			WHERE n.`email` = '".pSQL($email)."'
			AND n.`id_shop` = '".$this->context->shop->id."'
			AND (n.`date_deleted` IS NULL OR UNIX_TIMESTAMP(n.`date_deleted`) = 0)
		");
		
		if(!$result)
			return self::NOT_REGISTERED;
		elseif($result['id_customer'] and !$result['is_guest'])
			return self::CUSTOMER_REGISTERED;
		elseif($result['is_guest'])
			return self::GUEST_REGISTERED;
		
		return self::VISITOR_REGISTERED;
		
	}
	
	protected function isVeryfied($email) {
		
		return (bool)DB::getInstance()->getValue("SELECT `active` FROM "._DB_PREFIX_."newsletter WHERE email='".pSQL($email)."'");
		
	}
	
	private function processRegisterNewsletter($email, $active = false) {
		
		$email = pSQL($email);
		
		$register_status = $this->isNewsletterRegistered($email);
		
		if ($register_status > 0)
			return $this->error = $this->l('This email address is already registered.');
		
		if (!$this->isVeryfied($email)) {
			
			$now = date('Y-m-d H:i:s');
			
			if(!Db::getInstance()->execute("
				REPLACE INTO "._DB_PREFIX_."newsletter
				SET
					id_shop = '".$this->context->shop->id."',
					id_shop_group = '".$this->context->shop->id_shop_group."',
					id_customer = '".(isset($this->context->cart->id_customer) ? $this->context->cart->id_customer : '0')."',
					email = '".pSQL($email)."',
					newsletter_date_add = '".$now."',
					ip_registration_newsletter = '".pSQL(Tools::getRemoteAddr())."',
					http_referer = (
						SELECT c.http_referer
						FROM "._DB_PREFIX_."connections c
						WHERE c.id_guest = ".(int)$this->context->customer->id."
						ORDER BY c.date_add DESC LIMIT 1
					),
					active = '".(int)$active."',
					hash = '".$this->getHash($email)."',
					".(((int)$active || !Configuration::get('NW_VERIFICATION_EMAIL')) ? "`date_dbloptin`='".$now."'," : '')."
					date_add = '".$now."',
					date_upd = '".$now."'
			"))
				return $this->error = $this->l('An error occurred during the subscription process.');
			
			if(!$active and Configuration::get('NW_VERIFICATION_EMAIL')) {
				
				$this->sendVerificationEmail($email);
				
				/*
				if($this->sendVerificationEmail($email) === false);
					return $this->error = $this->l('Could not send verification email.');
				*/
				
				return $this->valid = $this->l('A verification email has been sent. Please check your inbox.');
				
			}
			else {

				if(Configuration::get('NW_CONFIRMATION_EMAIL'))
					$this->sendConfirmationEmail($email, Configuration::get('NW_VOUCHER_CODE'));
				
			}
			
		}
		
	}
	
	public function getHash($email) {
		
		return md5(pSQL($email)._COOKIE_KEY_);
		
	}
	
	protected function getEmailByHash($hash) {
		
		return Db::getInstance()->getValue("
			SELECT `email`
			FROM `"._DB_PREFIX_."newsletter`
			WHERE `hash` = '".pSQL($hash)."'
		");
		
	}
	
	// Subscribe / Unsubscribe
	public function activateNewsletter($email) {
		
		$now = date('Y-m-d H:i:s');
		
		return Db::getInstance()->execute("
			UPDATE `"._DB_PREFIX_."newsletter` SET
			`active` = 1,
			`date_dbloptin` = '".$now."',
			`date_upd` = '".$now."'
			WHERE `email` = '".pSQL($email)."'
		");
		
	}
	
	public function deactivateNewsletter($email) {
		
		$now = date('Y-m-d H:i:s');
		
		return Db::getInstance()->execute("
			UPDATE `"._DB_PREFIX_."newsletter` SET
			`active` = 0,
			`date_deleted` = '".$now."',
			`date_upd` = '".$now."'
			WHERE `email` = '".pSQL($email)."'
		");
		
	}
	
	public function confirmEmail($hash) {
		
		$email = $this->getEmailByHash($hash);
		
		if(!$email)
			return $this->l('This email is not registered and/or invalid.');
		
		$this->activateNewsletter($email);
		
		if (Configuration::get('NW_CONFIRMATION_EMAIL'))
			$this->sendConfirmationEmail($email, Configuration::get('NW_VOUCHER_CODE'));
		
		return $this->l('Thank you for subscribing to our newsletter.');
		
	}
	
	public function unsubscribeEmail($hash) {
		
		$email = $this->getEmailByHash($hash);
		
		if(!$email)
			return $this->l('This email is not registered and/or invalid.');
		
		$this->deactivateNewsletter($email);
		
		return $this->l('Your email was unsubscribed successfully.');
		
	}
	
	// Send Mails
	protected function sendConfirmationEmail($email, $code='') {
		
		$discount = '';
		
		if($code)
			$discount = sprintf($this->l('Regarding your newsletter subscription, we are pleased to offer you the following voucher: %s'), $code);
		
		$unsubscribe_url = Context::getContext()->link->getModuleLink('gc_newsletter', 'unsubscribe', array(
			'hash' => $this->getHash($email),
		));
		
		$data = array(
			'{discount}' => $discount,
			'{unsubscribe}' => $unsubscribe_url,
			'{email}' => $email
		);
		
		return	Mail::Send($this->context->language->id, 'newsletter_conf', $this->l('Newsletter confirmation'), $data, pSQL($email), null, null, null, null, null, dirname(__FILE__).'/mails/');
		
	}
	
	protected function sendVerificationEmail($email) {		
		
		$verif_url = Context::getContext()->link->getModuleLink('gc_newsletter', 'verification', array(
			'hash' => $this->getHash($email),
		));
		
		$unsubscribe_url = Context::getContext()->link->getModuleLink('gc_newsletter', 'unsubscribe', array(
			'hash' => $this->getHash($email),
		));
		
		$data = array(
			'{verif_url}' => $verif_url,
			'{unsubscribe}' => $unsubscribe_url,
			'{email}' => $email
		);
		
		return Mail::Send($this->context->language->id, 'newsletter_verif', $this->l('Email verification'), $data, $email, null, null, null, null, null, dirname(__FILE__).'/mails/');
		
	}
	
	// Hooks
	public function hookDisplayLeftColumn($params) {
		
		$this->context->controller->addCSS($this->_path.'views/gc_newsletter.css', 'all');
		
		if (Tools::isSubmit('submitNewsletter')) {
			
			if((!$email = Tools::getValue('email')) || (!Validate::isEmail($email)))
				$this->error = $this->l('Invalid email address');
			else
				$this->processRegisterNewsletter($email);
			
			if($this->error) {
				
				$this->smarty->assign(array(
					'msg' => $this->error,
					'nw_value' => isset($email) ? pSQL($email) : false,
					'nw_error' => true
				));
				
			}
			elseif($this->valid) {
				
				$this->smarty->assign(array(
					'msg' => $this->valid,
					'nw_error' => false
				));
				
			}
			
		}
		
		$this->smarty->assign('this_path', $this->_path);
		
		return $this->display(__FILE__, 'displayLeftColumn.tpl');
		
	}
	
	public function hookDisplayRightColumn($params) {
		
		return $this->hookDisplayLeftColumn($params);
		
	}
	
	public function hookDisplayFooter($params) {
		
		return $this->hookDisplayLeftColumn($params);
		
	}
	
	public function hookActionNewsletter($params) {
		
		$active = isset($params['active']) ? $params['active'] : false;
		$email = isset($params['email']) ? $params['email'] : false;
		
		$this->processRegisterNewsletter($email, (bool)$active);
		
	}
	
	// Custom Functions
	public function getModuleBOLink() {
		
		return 'index.php?controller=AdminModules&configure='.$this->name.'&token='.Tools::getvalue('token');
		
	}
	
	private function getExportNewsletter() {
		
		$dbquery_nl = new DbQuery();
		$dbquery_c = false;
		
		if(Tools::getValue('MERGECUSTOMER')) {
			
			$dbquery_c = new DbQuery();
			$dbquery_c->select("
				'' AS id, 
				c.`id_shop`, 
				c.`id_shop_group`, 
				c.`id_customer`, 
				c.`email`, 
				c.`newsletter_date_add`, 
				c.`ip_registration_newsletter`,
				'' as http_referer,
				0 as active,
				'' as hash,
				'0000-00-00 00:00:00' as date_dbloptin,
				'0000-00-00 00:00:00' as date_deleted,
				'0000-00-00 00:00:00' as date_add,
				'0000-00-00 00:00:00' as date_upd,
				c.`id_gender`, 
				c.`firstname`, 
				c.`lastname`,
				c.`is_guest`
			");
			$dbquery_c->from("customer", "c");
			
		}
		
		// Newsletter
		$dbquery_nl->select("
			n.`id`, 
			n.`id_shop`, 
			n.`id_shop_group`, 
			n.`id_customer`, 
			n.`email`,
			n.`newsletter_date_add`,
			n.`ip_registration_newsletter`, 
			n.`http_referer`, 
			n.`active`, 
			n.`hash`, 
			n.`date_dbloptin`, 
			n.`date_deleted`, 
			n.`date_add`, 
			n.`date_upd`
		");
		
		$dbquery_nl->from("newsletter", "n");
		
		// Customer
		$dbquery_nl->select("
			c.`id_gender`, 
			c.`firstname`, 
			c.`lastname`,
			c.`is_guest`
		");
		
		$dbquery_nl->leftJoin("customer", "c", "(n.`id_customer` = c.`id_customer`)");
		$dbquery_nl->where("n.`active` = '1'");
		
		// Group
		if($id_groups = Tools::getValue('GROUP')) {
			
			if($id_groups[0] != 0) {
				
				$dbquery_nl->where("
					(
						SELECT COUNT(cg.`id_group`) as nb_group
						FROM `"._DB_PREFIX_."customer_group` cg
						WHERE cg.`id_customer` = c.`id_customer`
						AND cg.`id_group` IN ('".implode("', '", $id_groups)."')
					) >= 1
				");
				
				if($dbquery_c)
					$dbquery_c->where("
						(
							SELECT COUNT(cg.`id_group`) as nb_group
							FROM `"._DB_PREFIX_."customer_group` cg
							WHERE cg.`id_customer` = c.`id_customer`
							AND cg.`id_group` IN ('".implode("', '", $id_groups)."')
						) >= 1
					");
				
			}
			
		}
		
		// Countries
		if($id_countries = Tools::getValue('COUNTRY')) {
			
			if($id_countries[0] != 0) {
				$dbquery_nl->where("
					(
						SELECT COUNT(a.`id_address`) as nb_country
						FROM `"._DB_PREFIX_."address` a
						WHERE a.deleted = 0
						AND a.`id_customer` = c.`id_customer`
						AND a.`id_country` IN ('".implode("', '", $id_countries)."')
					) >= 1
				");
				
				
					$dbquery_c->where("
						(
							SELECT COUNT(a.`id_address`) as nb_country
							FROM `"._DB_PREFIX_."address` a
							WHERE a.deleted = 0
							AND a.`id_customer` = c.`id_customer`
							AND a.`id_country` IN ('".implode("', '", $id_countries)."')
						) >= 1
					");
			
			}
			
		}
		
		// Zones
		if($id_zones = Tools::getValue('ZONE')) {
			
			if($id_zones[0] != 0) {
				
				$dbquery_nl->where("
					(
						SELECT COUNT(a2.`id_address`) as nb_country
						FROM `"._DB_PREFIX_."address` a2
						INNER JOIN `"._DB_PREFIX_."country` AS cy ON (cy.`id_country` = a2.`id_country` AND cy.`id_zone` IN ('".implode("', '", $id_zones)."'))
						WHERE a2.deleted = 0
						AND a2.`id_customer` = c.`id_customer`
					) >= 1
				");
				
				if($dbquery_c)
					$dbquery_c->where("
						(
							SELECT COUNT(a2.`id_address`) as nb_country
							FROM `"._DB_PREFIX_."address` a2
							INNER JOIN `"._DB_PREFIX_."country` AS cy ON (cy.`id_country` = a2.`id_country` AND cy.`id_zone` IN ('".implode("', '", $id_zones)."'))
							WHERE a2.deleted = 0
							AND a2.`id_customer` = c.`id_customer`
						) >= 1
					");
			
			}
			
		}
		
		// Date
		if($date_from = Tools::getValue('DATEADD_FROM') and $date_to = Tools::getValue('DATEADD_TO')) {
			
			$dbquery_nl->where("n.`newsletter_date_add` BETWEEN '".$date_from."' AND '".$date_to."'");
			
			if($dbquery_c)
				$dbquery_c->where("c.`newsletter_date_add` BETWEEN '".$date_from."' AND '".$date_to."'");
			
		}
		
		// Only Doubleoptin
		if(Tools::getValue('ONLYDBLOPTIN')) {
			
			$dbquery_nl->where("n.`date_dbloptin` != '0000-00-00 00:00:00' AND n.`date_dbloptin` IS NOT NULL");
			
		}
		
		// Deleted subscribers
		if(Tools::getValue('DELETED')) {
			
			$dbquery_nl->where("n.`date_deleted` != '0000-00-00 00:00:00' AND n.`date_deleted` IS NOT NULL");
			
		}
		
		// Broken cart
		if(Tools::getValue('CART')) {
			
			$dbquery_nl->where("
				(
					SELECT COUNT(ct.`id_cart`) as count_cart
					FROM `"._DB_PREFIX_."cart` ct
					INNER JOIN `"._DB_PREFIX_."orders` AS o ON (o.`id_cart` != ct.`id_cart`)
					WHERE ct.`id_customer` = c.`id_customer`
				) >= 1
			");
			
			if($dbquery_c)
				$dbquery_c->where("
					(
						SELECT COUNT(ct.`id_cart`) as count_cart
						FROM `"._DB_PREFIX_."cart` ct
						INNER JOIN `"._DB_PREFIX_."orders` AS o ON (o.`id_cart` != ct.`id_cart`)
						WHERE ct.`id_customer` = c.`id_customer`
					) >= 1
				");
			
		}
		
		$rq = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($dbquery_nl->build());
		
		if($dbquery_c)
			$rq2 = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($dbquery_c->build());
		
		foreach($rq as $key => $row) {
			
			$rq[$key][] = Context::getContext()->link->getModuleLink('gc_newsletter', 'unsubscribe', array('hash' => $this->getHash($row['email'])));
			
			if($dbquery_c) {
				
				foreach($rq2 as $a => $b)
					if($row['email'] == $b['email'])
						unset($rq2[$a]);
				
			}
			
		}
		
		if($dbquery_c and count($rq2) >= 1) {
			
			foreach($rq2 as $key => $row)
				$rq2[$key][] = '';
			
			$rq = array_merge($rq, $rq2);
		
		}
		
		$header = array(
			$this->l('id'), 
			$this->l('id_shop'), 
			$this->l('id_shop_group'), 
			$this->l('id_customer'), 
			$this->l('email'), 
			$this->l('newsletter_date_add'),
			$this->l('ip_registration_newsletter'),
			$this->l('http_referer'),
			$this->l('active'),
			$this->l('hash'),
			$this->l('date_dbloptin'),
			$this->l('date_deleted'),
			$this->l('date_add'),
			$this->l('date_upd'),
			$this->l('id_gender'),
			$this->l('firstname'),
			$this->l('lastname'),
			$this->l('is_guest'),
			$this->l('unsubscribe')
		);
		
		$result = (is_array($rq) ? array_merge(array($header), $rq) : $header);
		
		return $result;
		
	}

	private function fputcsv($fd, $array) {
		
		$line = implode(';', $array);
		$line .= "\n";
		if (!fwrite($fd, $line, 4096))
			$this->_postErrors[] = $this->l('Error: cannot write').' '.dirname(__FILE__).'/'.$this->_file.' !';
		
	}
	
}
