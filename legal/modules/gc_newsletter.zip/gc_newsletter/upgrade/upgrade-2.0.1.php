<?php

function upgrade_module_2_0_1($gc_newsletter) {
	
	$return = true;
	
	$return &= DB::getInstance()->execute("ALTER TABLE `"._DB_PREFIX_."newsletter` ADD `id_customer` INTEGER UNSIGNED NOT NULL DEFAULT '0', ADD UNIQUE (`email`)");
	
	$result = Db::getInstance()->executeS("
		SELECT id_customer, email FROM `"._DB_PREFIX_."customer`
		WHERE `newsletter` = '1'
		GROUP BY email
	");
	
	foreach($result as $row)
		$return &= Db::getInstance()->execute("
			UPDATE `"._DB_PREFIX_."newsletter` SET 
			id_customer='".$row['id_customer']."'
			WHERE id_customer = 0 AND email='".$row['email']."'
		");
			
	return $return;
	
}